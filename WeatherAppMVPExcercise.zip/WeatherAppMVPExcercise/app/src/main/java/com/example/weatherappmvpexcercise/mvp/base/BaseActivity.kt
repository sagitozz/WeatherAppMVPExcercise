package com.example.weatherappmvpexcercise.mvp.base

abstract class BaseActivity {


}