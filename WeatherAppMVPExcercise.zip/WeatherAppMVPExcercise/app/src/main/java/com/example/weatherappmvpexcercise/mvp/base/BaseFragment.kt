package com.example.weatherappmvpexcercise.mvp.base

import androidx.fragment.app.Fragment

class BaseFragment : Fragment() {
}